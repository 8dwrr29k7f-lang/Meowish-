"""
Multi-source live BTC market data.
Primary: Binance public REST (klines, depth, trades, funding, OI)
Secondary: Coinbase spot (cross-check)
Tracks timestamps and data age for every series.

Optimized for speed:
- Parallel HTTP via ThreadPoolExecutor
- Per-series TTL cache (higher TFs refresh less often)
- Funding / OI / Coinbase on longer cadence
"""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional, Tuple

import requests

BINANCE = "https://data-api.binance.vision"
BINANCE_FUTURES = "https://fapi.binance.com"
COINBASE = "https://api.coinbase.com"

# Refresh intervals (seconds) — higher TF candles change slowly
KLINE_TTL = {
    "1m": 3.0,
    "3m": 8.0,
    "5m": 10.0,
    "15m": 20.0,
    "30m": 45.0,
    "1h": 60.0,
    "4h": 120.0,
}
BOOK_TTL = 2.0
TRADES_TTL = 3.0
TICKER_TTL = 1.5
FUNDING_TTL = 120.0
OI_TTL = 120.0
COINBASE_TTL = 15.0


@dataclass
class SeriesMeta:
    source: str
    last_ts: float = 0.0          # wall-clock when we received it
    data_ts: float = 0.0          # exchange timestamp if known
    age_sec: float = 9999.0
    stale: bool = True
    error: Optional[str] = None


@dataclass
class Candle:
    open_time: float
    open: float
    high: float
    low: float
    close: float
    volume: float
    close_time: float


@dataclass
class MarketSnapshot:
    price: float = 0.0
    price_source: str = ""
    price_age: float = 9999.0
    price_ts: float = 0.0

    # multi-TF OHLCV (newest last)
    klines: Dict[str, List[Candle]] = field(default_factory=dict)
    kline_meta: Dict[str, SeriesMeta] = field(default_factory=dict)

    # order book
    bid: float = 0.0
    ask: float = 0.0
    bid_qty: float = 0.0
    ask_qty: float = 0.0
    imbalance: float = 0.0          # (bid_qty - ask_qty) / (bid+ask)
    book_age: float = 9999.0
    book_stale: bool = True

    # recent trades aggression
    buy_vol_1m: float = 0.0
    sell_vol_1m: float = 0.0
    trade_imbalance: float = 0.0
    trades_age: float = 9999.0

    # futures
    funding_rate: Optional[float] = None
    open_interest: Optional[float] = None
    funding_age: float = 9999.0
    oi_age: float = 9999.0

    # cross-check
    coinbase_price: Optional[float] = None
    price_divergence_bps: float = 0.0

    fetched_at: float = 0.0
    errors: List[str] = field(default_factory=list)

    def is_usable(self, max_price_age: float = 8.0) -> bool:
        return self.price > 0 and self.price_age <= max_price_age and not any(
            "fatal" in e.lower() for e in self.errors
        )


class DataFeed:
    INTERVALS = ["1m", "3m", "5m", "15m", "30m", "1h", "4h"]
    KLINE_LIMIT = 60

    def __init__(self, symbol: str = "BTCUSDT", stale_sec: float = 12.0, workers: int = 10):
        self.symbol = symbol
        self.stale_sec = stale_sec
        self._session = requests.Session()
        self._session.headers.update({"User-Agent": "xvantage-predictor/3.1"})
        # connection pool for parallel requests
        adapter = requests.adapters.HTTPAdapter(
            pool_connections=workers,
            pool_maxsize=workers,
            max_retries=0,
        )
        self._session.mount("https://", adapter)
        self._spot: Deque[Tuple[float, float]] = deque(maxlen=1200)
        self.last_snapshot: Optional[MarketSnapshot] = None
        self._pool = ThreadPoolExecutor(max_workers=workers)

        # caches: key -> (value, meta, fetched_at)
        self._kline_cache: Dict[str, Tuple[List[Candle], SeriesMeta, float]] = {}
        self._book_cache: Optional[Tuple[dict, SeriesMeta, float]] = None
        self._trades_cache: Optional[Tuple[list, SeriesMeta, float]] = None
        self._ticker_cache: Optional[Tuple[float, SeriesMeta, float]] = None
        self._funding_cache: Optional[Tuple[Optional[float], SeriesMeta, float]] = None
        self._oi_cache: Optional[Tuple[Optional[float], SeriesMeta, float]] = None
        self._coinbase_cache: Optional[Tuple[Optional[float], SeriesMeta, float]] = None

    def _get(self, url: str, params: Optional[dict] = None, timeout: float = 3.5) -> Any:
        r = self._session.get(url, params=params, timeout=timeout)
        r.raise_for_status()
        return r.json()

    def _parse_klines(self, raw: list) -> List[Candle]:
        out = []
        for row in raw:
            out.append(
                Candle(
                    open_time=row[0] / 1000.0,
                    open=float(row[1]),
                    high=float(row[2]),
                    low=float(row[3]),
                    close=float(row[4]),
                    volume=float(row[5]),
                    close_time=row[6] / 1000.0,
                )
            )
        return out

    # ── raw fetchers (no cache) ──────────────────────────────────────────

    def _raw_klines(self, interval: str, limit: int = 60) -> Tuple[List[Candle], SeriesMeta]:
        meta = SeriesMeta(source=f"binance:{interval}")
        now = time.time()
        try:
            raw = self._get(
                f"{BINANCE}/api/v3/klines",
                {"symbol": self.symbol, "interval": interval, "limit": limit},
            )
            candles = self._parse_klines(raw)
            meta.last_ts = now
            if candles:
                meta.data_ts = candles[-1].close_time
                meta.age_sec = max(0.0, now - meta.data_ts)
            meta.stale = meta.age_sec > self.stale_sec * (2 if interval != "1m" else 1)
            return candles, meta
        except Exception as e:
            meta.error = str(e)
            meta.stale = True
            meta.last_ts = now
            return [], meta

    def _raw_book(self, limit: int = 20) -> Tuple[dict, SeriesMeta]:
        meta = SeriesMeta(source="binance:depth")
        now = time.time()
        try:
            data = self._get(
                f"{BINANCE}/api/v3/depth",
                {"symbol": self.symbol, "limit": limit},
            )
            meta.last_ts = now
            meta.data_ts = now
            meta.age_sec = 0.0
            meta.stale = False
            return data, meta
        except Exception as e:
            meta.error = str(e)
            meta.stale = True
            return {}, meta

    def _raw_trades(self, limit: int = 100) -> Tuple[list, SeriesMeta]:
        meta = SeriesMeta(source="binance:trades")
        now = time.time()
        try:
            data = self._get(
                f"{BINANCE}/api/v3/trades",
                {"symbol": self.symbol, "limit": limit},
            )
            meta.last_ts = now
            if data:
                meta.data_ts = data[-1]["time"] / 1000.0
                meta.age_sec = max(0.0, now - meta.data_ts)
            meta.stale = meta.age_sec > self.stale_sec
            return data, meta
        except Exception as e:
            meta.error = str(e)
            meta.stale = True
            return [], meta

    def _raw_funding(self) -> Tuple[Optional[float], SeriesMeta]:
        meta = SeriesMeta(source="binance:funding")
        now = time.time()
        try:
            data = self._get(
                f"{BINANCE_FUTURES}/fapi/v1/premiumIndex",
                {"symbol": self.symbol},
            )
            rate = float(data.get("lastFundingRate") or data.get("interestRate") or 0)
            meta.last_ts = now
            meta.data_ts = now
            meta.age_sec = 0.0
            meta.stale = False
            return rate, meta
        except Exception as e:
            meta.error = str(e)
            meta.stale = True
            return None, meta

    def _raw_oi(self) -> Tuple[Optional[float], SeriesMeta]:
        meta = SeriesMeta(source="binance:oi")
        now = time.time()
        try:
            data = self._get(
                f"{BINANCE_FUTURES}/fapi/v1/openInterest",
                {"symbol": self.symbol},
            )
            oi = float(data.get("openInterest") or 0)
            meta.last_ts = now
            meta.data_ts = now
            meta.age_sec = 0.0
            meta.stale = False
            return oi, meta
        except Exception as e:
            meta.error = str(e)
            meta.stale = True
            return None, meta

    def _raw_coinbase(self) -> Tuple[Optional[float], SeriesMeta]:
        meta = SeriesMeta(source="coinbase:spot")
        now = time.time()
        try:
            data = self._get(f"{COINBASE}/v2/prices/BTC-USD/spot")
            px = float(data["data"]["amount"])
            meta.last_ts = now
            meta.data_ts = now
            meta.age_sec = 0.0
            meta.stale = False
            return px, meta
        except Exception as e:
            meta.error = str(e)
            meta.stale = True
            return None, meta

    def _raw_ticker(self) -> Tuple[float, SeriesMeta]:
        meta = SeriesMeta(source="binance:ticker")
        now = time.time()
        try:
            data = self._get(f"{BINANCE}/api/v3/ticker/price", {"symbol": self.symbol})
            px = float(data["price"])
            meta.last_ts = now
            meta.data_ts = now
            meta.age_sec = 0.0
            meta.stale = False
            self._spot.append((now, px))
            return px, meta
        except Exception as e:
            meta.error = str(e)
            meta.stale = True
            if self._spot:
                return self._spot[-1][1], meta
            return 0.0, meta

    # ── cached accessors ─────────────────────────────────────────────────

    def _need(self, cached: Optional[Tuple], ttl: float, now: float) -> bool:
        if cached is None:
            return True
        return (now - cached[2]) >= ttl

    def snapshot(self, intervals: Optional[List[str]] = None, force: bool = False) -> MarketSnapshot:
        """Fetch a coherent multi-source snapshot. Parallel + cached for ~0.3–0.6s cycles."""
        now = time.time()
        snap = MarketSnapshot(fetched_at=now)
        intervals = intervals or self.INTERVALS

        # Decide which series need a network round-trip
        jobs: Dict[str, Any] = {}  # job_id -> future

        def submit(key: str, fn, *args):
            jobs[key] = self._pool.submit(fn, *args)

        if force or self._need(self._ticker_cache, TICKER_TTL, now):
            submit("ticker", self._raw_ticker)

        for iv in intervals:
            ttl = KLINE_TTL.get(iv, 15.0)
            cached = self._kline_cache.get(iv)
            if force or self._need(cached, ttl, now):
                submit(f"kline:{iv}", self._raw_klines, iv, self.KLINE_LIMIT)

        if force or self._need(self._book_cache, BOOK_TTL, now):
            submit("book", self._raw_book, 20)

        if force or self._need(self._trades_cache, TRADES_TTL, now):
            submit("trades", self._raw_trades, 80)

        if force or self._need(self._funding_cache, FUNDING_TTL, now):
            submit("funding", self._raw_funding)

        if force or self._need(self._oi_cache, OI_TTL, now):
            submit("oi", self._raw_oi)

        if force or self._need(self._coinbase_cache, COINBASE_TTL, now):
            submit("coinbase", self._raw_coinbase)

        # Collect results
        results: Dict[str, Any] = {}
        for key, fut in jobs.items():
            try:
                results[key] = fut.result(timeout=5.0)
            except Exception as e:
                results[key] = e

        # ── apply ticker ──
        if "ticker" in results and not isinstance(results["ticker"], Exception):
            px, meta_px = results["ticker"]
            self._ticker_cache = (px, meta_px, now)
        elif self._ticker_cache:
            px, meta_px, _ = self._ticker_cache
            meta_px = SeriesMeta(
                source=meta_px.source,
                last_ts=meta_px.last_ts,
                data_ts=meta_px.data_ts,
                age_sec=now - meta_px.last_ts,
                stale=(now - meta_px.last_ts) > self.stale_sec,
                error=meta_px.error,
            )
        else:
            px, meta_px = 0.0, SeriesMeta(source="binance:ticker", error="no ticker", stale=True)

        if isinstance(results.get("ticker"), Exception):
            snap.errors.append(f"ticker: {results['ticker']}")
            if self._ticker_cache:
                px, meta_px, _ = self._ticker_cache

        snap.price = px
        snap.price_source = meta_px.source
        snap.price_age = meta_px.age_sec
        snap.price_ts = meta_px.last_ts
        if meta_px.error:
            snap.errors.append(f"ticker: {meta_px.error}")

        # ── apply klines ──
        for iv in intervals:
            key = f"kline:{iv}"
            if key in results and not isinstance(results[key], Exception):
                candles, meta = results[key]
                self._kline_cache[iv] = (candles, meta, now)
            elif iv in self._kline_cache:
                candles, meta, cached_at = self._kline_cache[iv]
                meta = SeriesMeta(
                    source=meta.source,
                    last_ts=meta.last_ts,
                    data_ts=meta.data_ts,
                    age_sec=max(0.0, now - meta.data_ts) if meta.data_ts else now - cached_at,
                    stale=True,
                    error=meta.error,
                )
            else:
                candles, meta = [], SeriesMeta(source=f"binance:{iv}", error="no data", stale=True)

            if isinstance(results.get(key), Exception):
                snap.errors.append(f"kline:{iv}: {results[key]}")
                if iv in self._kline_cache:
                    candles, meta, _ = self._kline_cache[iv]

            snap.klines[iv] = candles
            snap.kline_meta[iv] = meta
            if meta.error:
                snap.errors.append(f"kline:{iv}: {meta.error}")

        # ── apply book ──
        book, meta_b = {}, SeriesMeta(source="binance:depth", stale=True)
        if "book" in results and not isinstance(results["book"], Exception):
            book, meta_b = results["book"]
            self._book_cache = (book, meta_b, now)
        elif self._book_cache:
            book, meta_b, cached_at = self._book_cache
            meta_b = SeriesMeta(
                source=meta_b.source,
                last_ts=meta_b.last_ts,
                data_ts=meta_b.data_ts,
                age_sec=now - cached_at,
                stale=(now - cached_at) > self.stale_sec,
            )
        if isinstance(results.get("book"), Exception):
            snap.errors.append(f"book: {results['book']}")
            if self._book_cache:
                book, meta_b, _ = self._book_cache

        if book:
            bids = book.get("bids") or []
            asks = book.get("asks") or []
            if bids:
                snap.bid = float(bids[0][0])
                snap.bid_qty = sum(float(x[1]) for x in bids[:10])
            if asks:
                snap.ask = float(asks[0][0])
                snap.ask_qty = sum(float(x[1]) for x in asks[:10])
            tot = snap.bid_qty + snap.ask_qty
            snap.imbalance = (snap.bid_qty - snap.ask_qty) / tot if tot > 0 else 0.0
            snap.book_age = meta_b.age_sec
            snap.book_stale = meta_b.stale
        if meta_b.error:
            snap.errors.append(f"book: {meta_b.error}")
            snap.book_stale = True

        # ── apply trades ──
        trades, meta_t = [], SeriesMeta(source="binance:trades", stale=True)
        if "trades" in results and not isinstance(results["trades"], Exception):
            trades, meta_t = results["trades"]
            self._trades_cache = (trades, meta_t, now)
        elif self._trades_cache:
            trades, meta_t, cached_at = self._trades_cache
            meta_t = SeriesMeta(
                source=meta_t.source,
                last_ts=meta_t.last_ts,
                data_ts=meta_t.data_ts,
                age_sec=now - cached_at,
                stale=(now - cached_at) > self.stale_sec,
            )
        if isinstance(results.get("trades"), Exception):
            snap.errors.append(f"trades: {results['trades']}")
            if self._trades_cache:
                trades, meta_t, _ = self._trades_cache

        if trades:
            cutoff = now - 60
            buy_v = sell_v = 0.0
            for t in trades:
                ts = t["time"] / 1000.0
                if ts < cutoff:
                    continue
                qty = float(t["qty"])
                if t.get("isBuyerMaker"):
                    sell_v += qty
                else:
                    buy_v += qty
            snap.buy_vol_1m = buy_v
            snap.sell_vol_1m = sell_v
            tot = buy_v + sell_v
            snap.trade_imbalance = (buy_v - sell_v) / tot if tot > 0 else 0.0
            snap.trades_age = meta_t.age_sec
        if meta_t.error:
            snap.errors.append(f"trades: {meta_t.error}")

        # ── funding (cache failures too — often geo-blocked 451) ──
        if "funding" in results:
            if not isinstance(results["funding"], Exception):
                fr, meta_f = results["funding"]
                self._funding_cache = (fr, meta_f, now)
            else:
                err = str(results["funding"])
                meta_f = SeriesMeta(source="binance:funding", error=err, stale=True, last_ts=now)
                self._funding_cache = (None, meta_f, now)  # backoff on failure
                if "451" not in err:
                    snap.errors.append(f"funding: {err}")
                fr = None
        elif self._funding_cache:
            fr, meta_f, _ = self._funding_cache
        else:
            fr, meta_f = None, SeriesMeta(source="binance:funding", stale=True)
        snap.funding_rate = fr
        snap.funding_age = meta_f.age_sec if meta_f else 9999.0

        # ── OI (cache failures too) ──
        if "oi" in results:
            if not isinstance(results["oi"], Exception):
                oi, meta_o = results["oi"]
                self._oi_cache = (oi, meta_o, now)
            else:
                err = str(results["oi"])
                meta_o = SeriesMeta(source="binance:oi", error=err, stale=True, last_ts=now)
                self._oi_cache = (None, meta_o, now)
                if "451" not in err:
                    snap.errors.append(f"oi: {err}")
                oi = None
        elif self._oi_cache:
            oi, meta_o, _ = self._oi_cache
        else:
            oi, meta_o = None, SeriesMeta(source="binance:oi", stale=True)
        snap.open_interest = oi
        snap.oi_age = meta_o.age_sec if meta_o else 9999.0

        # ── coinbase ──
        if "coinbase" in results and not isinstance(results["coinbase"], Exception):
            cb, meta_c = results["coinbase"]
            self._coinbase_cache = (cb, meta_c, now)
        elif self._coinbase_cache:
            cb, meta_c, _ = self._coinbase_cache
        else:
            cb = None
        if isinstance(results.get("coinbase"), Exception):
            if self._coinbase_cache:
                cb, _, _ = self._coinbase_cache
            else:
                cb = None
        snap.coinbase_price = cb
        if cb and px > 0:
            snap.price_divergence_bps = abs(cb - px) / px * 10000
            if snap.price_divergence_bps > 30:
                snap.errors.append(
                    f"price divergence {snap.price_divergence_bps:.1f} bps binance vs coinbase"
                )

        self.last_snapshot = snap
        return snap

    def momentum_pct(self, seconds: float = 60.0) -> Optional[float]:
        if len(self._spot) < 3:
            return None
        now = time.time()
        window = [(t, p) for t, p in self._spot if now - t <= seconds]
        if len(window) < 2:
            return None
        a, b = window[0][1], window[-1][1]
        if a <= 0:
            return None
        return (b - a) / a * 100.0

    def close(self) -> None:
        self._pool.shutdown(wait=False)
