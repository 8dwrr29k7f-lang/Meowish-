"""
Walk-forward backtest on historical Binance 1m/15m klines.
No look-ahead: features use only candles fully closed before decision time.
Compares ensemble vs baselines (random, previous candle).
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import requests

from core.features import FeatureSet
from core.models import ALL_MODELS
from core.ensemble import combine
from core.regime import Regime, detect_regime
from core.data_feed import Candle


BINANCE = "https://data-api.binance.vision"


def fetch_historical_klines(
    symbol: str = "BTCUSDT",
    interval: str = "1m",
    limit: int = 1000,
) -> List[Candle]:
    r = requests.get(
        f"{BINANCE}/api/v3/klines",
        params={"symbol": symbol, "interval": interval, "limit": limit},
        timeout=20,
    )
    r.raise_for_status()
    out = []
    for row in r.json():
        out.append(
            Candle(
                open_time=row[0] / 1000.0,
                open=float(row[1]),
                high=float(row[2]),
                low=float(row[3]),
                close=float(row[4]),
                volume=float(row[5]),
                close_time=row[6] / 1000.0,
            )
        )
    return out


def _slice_features(c15: List[Candle], c1h: List[Candle], i15: int) -> FeatureSet:
    """Build features using only candles up to index i15 (inclusive, closed)."""
    window15 = c15[max(0, i15 - 50) : i15 + 1]
    # approximate 1h by sampling every 4 of 15m if needed
    window1h = c1h[max(0, (i15 // 4) - 40) : (i15 // 4) + 1] if c1h else []

    closes15 = [c.close for c in window15]
    closes1h = [c.close for c in window1h]
    vols15 = [c.volume for c in window15]

    fs = FeatureSet(price=closes15[-1] if closes15 else 0)
    if len(closes15) >= 2:
        fs.ret_15m = (closes15[-1] / closes15[-2] - 1) * 100
    if len(closes15) >= 6:
        fs.ret_5m = (closes15[-1] / closes15[-2] - 1) * 100  # proxy
        # slope
        n = min(8, len(closes15))
        xs = list(range(n))
        ys = closes15[-n:]
        xbar = (n - 1) / 2
        ybar = sum(ys) / n
        num = sum((x - xbar) * (y - ybar) for x, y in zip(xs, ys))
        den = sum((x - xbar) ** 2 for x in xs) or 1
        fs.slope_15m = (num / den) / closes15[-1] * 100

    # RSI
    if len(closes15) >= 15:
        gains = losses = 0.0
        for j in range(-14, 0):
            d = closes15[j] - closes15[j - 1]
            if d >= 0:
                gains += d
            else:
                losses -= d
        if losses == 0:
            fs.rsi_14_15m = 100.0
        else:
            rs = (gains / 14) / (losses / 14)
            fs.rsi_14_15m = 100 - 100 / (1 + rs)

    # ATR pct
    if len(window15) >= 15:
        trs = []
        for j in range(-14, 0):
            c = window15[j]
            prev = window15[j - 1].close
            tr = max(c.high - c.low, abs(c.high - prev), abs(c.low - prev))
            trs.append(tr)
        atr = sum(trs) / 14
        fs.atr_15m_pct = atr / closes15[-1] * 100

    if len(vols15) >= 20:
        mu = sum(vols15[-20:]) / 20
        var = sum((v - mu) ** 2 for v in vols15[-20:]) / 20
        sd = var ** 0.5 or 1e-12
        fs.vol_z_15m = (vols15[-1] - mu) / sd

    if len(closes15) >= 20:
        sma = sum(closes15[-20:]) / 20
        fs.above_sma20_15m = closes15[-1] > sma
        fs.dist_sma20_15m_pct = (closes15[-1] / sma - 1) * 100

    if len(closes1h) >= 2:
        fs.ret_1h = (closes1h[-1] / closes1h[-2] - 1) * 100
        if len(closes1h) >= 12:
            n = 12
            xs = list(range(n))
            ys = closes1h[-n:]
            xbar = (n - 1) / 2
            ybar = sum(ys) / n
            num = sum((x - xbar) * (y - ybar) for x, y in zip(xs, ys))
            den = sum((x - xbar) ** 2 for x in xs) or 1
            fs.slope_1h = (num / den) / closes1h[-1] * 100
        if len(closes1h) >= 20:
            sma = sum(closes1h[-20:]) / 20
            fs.above_sma20_1h = closes1h[-1] > sma

    fs.book_imbalance = 0.0
    fs.trade_imbalance = 0.0
    fs.stale = False
    fs.data_age_sec = 0.0
    return fs


@dataclass
class BacktestResult:
    n: int = 0
    accuracy: float = 0.0
    precision_up: float = 0.0
    recall_up: float = 0.0
    precision_down: float = 0.0
    recall_down: float = 0.0
    f1: float = 0.0
    brier: float = 0.0
    baseline_prev_acc: float = 0.0
    baseline_random_acc: float = 0.5
    neutral_rate: float = 0.0
    by_regime: Dict[str, Dict] = field(default_factory=dict)
    notes: List[str] = field(default_factory=list)


def run_walk_forward(
    symbol: str = "BTCUSDT",
    bars_15m: int = 500,
    conf_threshold: float = 0.12,
) -> BacktestResult:
    """
    Walk-forward on last `bars_15m` closed 15m candles.
    Decision at close of bar i; outcome = sign of return from i to i+1.
    """
    c15 = fetch_historical_klines(symbol, "15m", min(bars_15m + 60, 1000))
    c1h = fetch_historical_klines(symbol, "1h", 300)

    if len(c15) < 80:
        return BacktestResult(notes=["insufficient history"])

    # Use first 40% as burn-in (no scoring), remaining as test
    start = max(40, int(len(c15) * 0.35))
    end = len(c15) - 2  # need i+1 for outcome

    y_true = []       # 1 = UP
    y_pred = []       # 1 = UP, 0 = DOWN, -1 = NEUTRAL
    p_ups = []
    regimes = []
    prev_correct = []

    for i in range(start, end):
        fs = _slice_features(c15, c1h, i)
        regime = detect_regime(fs)
        outputs = [m.predict(fs, regime) for m in ALL_MODELS]
        ens = combine(outputs, regime.strength)

        conf = ens.confidence
        if conf < conf_threshold or abs(ens.p_up - 0.5) < 0.02:
            direction = -1  # neutral
        elif ens.p_up >= 0.5:
            direction = 1
        else:
            direction = 0

        # actual
        ret = (c15[i + 1].close / c15[i].close - 1.0) * 100
        actual = 1 if ret > 0 else 0

        y_true.append(actual)
        y_pred.append(direction)
        p_ups.append(ens.p_up)
        regimes.append(regime.name)

        # baseline: previous candle direction
        prev_ret = (c15[i].close / c15[i - 1].close - 1.0) if i > 0 else 0
        prev_dir = 1 if prev_ret > 0 else 0
        prev_correct.append(1 if prev_dir == actual else 0)

    # Metrics on directional only
    directional = [(yt, yp, pu) for yt, yp, pu in zip(y_true, y_pred, p_ups) if yp >= 0]
    n_dir = len(directional)
    if n_dir == 0:
        return BacktestResult(n=0, notes=["no directional predictions"])

    correct = sum(1 for yt, yp, _ in directional if yt == yp)
    acc = correct / n_dir

    # Precision/recall UP
    tp_up = sum(1 for yt, yp, _ in directional if yt == 1 and yp == 1)
    fp_up = sum(1 for yt, yp, _ in directional if yt == 0 and yp == 1)
    fn_up = sum(1 for yt, yp, _ in directional if yt == 1 and yp == 0)
    prec_up = tp_up / (tp_up + fp_up) if (tp_up + fp_up) else 0.0
    rec_up = tp_up / (tp_up + fn_up) if (tp_up + fn_up) else 0.0

    tp_dn = sum(1 for yt, yp, _ in directional if yt == 0 and yp == 0)
    fp_dn = sum(1 for yt, yp, _ in directional if yt == 1 and yp == 0)
    fn_dn = sum(1 for yt, yp, _ in directional if yt == 0 and yp == 1)
    prec_dn = tp_dn / (tp_dn + fp_dn) if (tp_dn + fp_dn) else 0.0
    rec_dn = tp_dn / (tp_dn + fn_dn) if (tp_dn + fn_dn) else 0.0

    f1_up = 2 * prec_up * rec_up / (prec_up + rec_up) if (prec_up + rec_up) else 0
    f1_dn = 2 * prec_dn * rec_dn / (prec_dn + rec_dn) if (prec_dn + rec_dn) else 0
    f1 = (f1_up + f1_dn) / 2

    brier = sum((pu - yt) ** 2 for yt, _, pu in directional) / n_dir
    neutral_rate = sum(1 for yp in y_pred if yp < 0) / len(y_pred)
    base_prev = sum(prev_correct) / len(prev_correct) if prev_correct else 0.5

    # By regime
    by_reg: Dict[str, Dict] = {}
    for reg, yt, yp in zip(regimes, y_true, y_pred):
        if yp < 0:
            continue
        slot = by_reg.setdefault(reg, {"n": 0, "correct": 0})
        slot["n"] += 1
        if yt == yp:
            slot["correct"] += 1
    for k, v in by_reg.items():
        v["accuracy"] = v["correct"] / v["n"] if v["n"] else None

    return BacktestResult(
        n=n_dir,
        accuracy=round(acc, 4),
        precision_up=round(prec_up, 4),
        recall_up=round(rec_up, 4),
        precision_down=round(prec_dn, 4),
        recall_down=round(rec_dn, 4),
        f1=round(f1, 4),
        brier=round(brier, 4),
        baseline_prev_acc=round(base_prev, 4),
        baseline_random_acc=0.5,
        neutral_rate=round(neutral_rate, 4),
        by_regime=by_reg,
        notes=[
            f"walk-forward test bars={end - start}",
            f"directional={n_dir} neutral_rate={neutral_rate:.1%}",
            "no book/trade features in historical path (REST-only)",
        ],
    )
