"""
BTC (and optional ETH) spot price feed using Coinbase public API.
Keeps a rolling window for momentum, velocity, candle streaks, and range.
"""

from __future__ import annotations

import time
from collections import deque
from typing import Deque, List, Optional, Tuple

import requests


class BTCPriceFeed:
    def __init__(self, maxlen: int = 900, symbol: str = "BTC-USD"):
        self.symbol = symbol
        self.prices: Deque[Tuple[float, float]] = deque(maxlen=maxlen)
        self.last: Optional[float] = None
        self.last_update: float = 0.0
        self._session = requests.Session()

    def update(self, force: bool = False) -> Optional[float]:
        now = time.time()
        if not force and (now - self.last_update) < 1.2:
            return self.last

        try:
            r = self._session.get(
                f"https://api.coinbase.com/v2/prices/{self.symbol}/spot",
                timeout=4,
            )
            r.raise_for_status()
            price = float(r.json()["data"]["amount"])
            self.prices.append((now, price))
            self.last = price
            self.last_update = now
            return price
        except Exception as e:
            print(f"  [price_feed] update failed: {e}")
            return self.last

    def momentum(self, seconds: float = 60.0) -> Optional[float]:
        """Percent change over the last `seconds`."""
        if len(self.prices) < 3:
            return None
        now = time.time()
        window = [(t, p) for t, p in self.prices if now - t <= seconds]
        if len(window) < 2:
            return None
        start_p = window[0][1]
        end_p = window[-1][1]
        if start_p <= 0:
            return None
        return (end_p - start_p) / start_p * 100.0

    def velocity(self, seconds: float = 30.0) -> Optional[float]:
        return self.momentum(seconds)

    def last_price(self) -> Optional[float]:
        return self.last

    def range_usd(self, seconds: float = 120.0) -> Optional[float]:
        """High-low range in USD over the window."""
        if len(self.prices) < 3:
            return None
        now = time.time()
        window = [p for t, p in self.prices if now - t <= seconds]
        if len(window) < 2:
            return None
        return max(window) - min(window)

    def falling_candles(self, bucket_sec: float = 15.0, lookback: int = 6) -> int:
        """
        Approximate sequential down-buckets (pseudo-candles).
        Returns count of consecutive falling buckets ending at now.
        """
        if len(self.prices) < 10:
            return 0
        now = time.time()
        # Build bucket closes
        closes: List[float] = []
        for i in range(lookback, 0, -1):
            end = now - (i - 1) * bucket_sec
            start = end - bucket_sec
            pts = [p for t, p in self.prices if start <= t <= end]
            if pts:
                closes.append(pts[-1])
        if len(closes) < 2:
            return 0
        streak = 0
        for i in range(len(closes) - 1, 0, -1):
            if closes[i] < closes[i - 1]:
                streak += 1
            else:
                break
        return streak

    def rising_candles(self, bucket_sec: float = 15.0, lookback: int = 6) -> int:
        if len(self.prices) < 10:
            return 0
        now = time.time()
        closes: List[float] = []
        for i in range(lookback, 0, -1):
            end = now - (i - 1) * bucket_sec
            start = end - bucket_sec
            pts = [p for t, p in self.prices if start <= t <= end]
            if pts:
                closes.append(pts[-1])
        if len(closes) < 2:
            return 0
        streak = 0
        for i in range(len(closes) - 1, 0, -1):
            if closes[i] > closes[i - 1]:
                streak += 1
            else:
                break
        return streak

    def line_crossings(self, seconds: float = 90.0, threshold_pct: float = 0.02) -> int:
        """Count rough direction flips above a small threshold."""
        if len(self.prices) < 5:
            return 0
        now = time.time()
        window = [(t, p) for t, p in self.prices if now - t <= seconds]
        if len(window) < 4:
            return 0
        flips = 0
        prev_dir = 0
        for i in range(1, len(window)):
            chg = (window[i][1] - window[i - 1][1]) / max(window[i - 1][1], 1e-9) * 100
            if abs(chg) < threshold_pct:
                continue
            d = 1 if chg > 0 else -1
            if prev_dir and d != prev_dir:
                flips += 1
            prev_dir = d
        return flips
