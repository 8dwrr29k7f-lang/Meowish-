"""
Kalshi API v2 client with RSA-PSS / Ed25519 signing.
Supports paper mode (no real orders) and live mode.
Handles both cents and dollar-denominated price fields.
"""

from __future__ import annotations

import base64
import time
import uuid
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

import requests
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, padding


def _to_cents(val: Any) -> int:
    """Normalize price to integer cents (0-100). Accepts dollars float/str or cents int."""
    if val is None:
        return 0
    try:
        f = float(val)
        if f <= 1.5:  # likely dollars (0.00 - 1.00)
            return max(0, min(100, int(round(f * 100))))
        return max(0, min(100, int(round(f))))
    except (TypeError, ValueError):
        return 0


def _to_float_size(val: Any) -> float:
    try:
        return float(val or 0)
    except (TypeError, ValueError):
        return 0.0


class KalshiClient:
    def __init__(
        self,
        api_key_id: Optional[str] = None,
        private_key_path: Optional[str] = None,
        env: str = "demo",
        paper: bool = True,
    ):
        self.paper = paper
        self.api_key_id = api_key_id
        self.private_key = None
        self.env = env

        if private_key_path and Path(private_key_path).exists():
            with open(private_key_path, "rb") as f:
                self.private_key = serialization.load_pem_private_key(
                    f.read(), password=None, backend=default_backend()
                )

        # Prefer external-api host; elections alias still works
        if env == "demo":
            self.base = "https://demo-api.kalshi.co/trade-api/v2"
        else:
            self.base = "https://api.elections.kalshi.com/trade-api/v2"

        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "xvantage-signals/2.0"})

    # ------------------------------------------------------------------
    # Signing
    # ------------------------------------------------------------------
    def _sign_headers(self, method: str, full_path: str) -> dict:
        if self.paper or not self.private_key or not self.api_key_id:
            return {}

        ts = str(int(time.time() * 1000))
        path_clean = full_path.split("?")[0]
        message = f"{ts}{method.upper()}{path_clean}".encode("utf-8")

        if isinstance(self.private_key, ed25519.Ed25519PrivateKey):
            signature = self.private_key.sign(message)
        else:
            signature = self.private_key.sign(
                message,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.DIGEST_LENGTH,
                ),
                hashes.SHA256(),
            )

        return {
            "KALSHI-ACCESS-KEY": self.api_key_id,
            "KALSHI-ACCESS-TIMESTAMP": ts,
            "KALSHI-ACCESS-SIGNATURE": base64.b64encode(signature).decode(),
        }

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------
    def get(self, path: str, params: Optional[dict] = None) -> dict:
        url = self.base + path
        sign_path = urlparse(url).path
        headers = self._sign_headers("GET", sign_path)
        resp = self.session.get(url, headers=headers, params=params, timeout=12)
        resp.raise_for_status()
        return resp.json()

    def post(self, path: str, json_body: dict) -> dict:
        if self.paper:
            print(f"  [PAPER] POST {path} → {json_body}")
            return {
                "order": {
                    "order_id": f"paper-{uuid.uuid4().hex[:12]}",
                    "status": "resting",
                    "ticker": json_body.get("ticker"),
                    "side": json_body.get("side"),
                    "action": json_body.get("action"),
                    "count": json_body.get("count"),
                }
            }

        url = self.base + path
        sign_path = urlparse(url).path
        headers = self._sign_headers("POST", sign_path)
        headers["Content-Type"] = "application/json"
        resp = self.session.post(url, headers=headers, json=json_body, timeout=12)
        resp.raise_for_status()
        return resp.json()

    def delete(self, path: str) -> dict:
        if self.paper:
            print(f"  [PAPER] DELETE {path}")
            return {"status": "canceled"}
        url = self.base + path
        sign_path = urlparse(url).path
        headers = self._sign_headers("DELETE", sign_path)
        resp = self.session.delete(url, headers=headers, timeout=12)
        resp.raise_for_status()
        return resp.json() if resp.content else {"status": "ok"}

    # ------------------------------------------------------------------
    # Market helpers (normalize to cents + common fields)
    # ------------------------------------------------------------------
    @staticmethod
    def normalize_market(m: dict) -> dict:
        """Return a clean market dict with integer-cent prices and useful meta."""
        yes_bid = _to_cents(m.get("yes_bid_dollars") or m.get("yes_bid"))
        yes_ask = _to_cents(m.get("yes_ask_dollars") or m.get("yes_ask"))
        no_bid = _to_cents(m.get("no_bid_dollars") or m.get("no_bid"))
        no_ask = _to_cents(m.get("no_ask_dollars") or m.get("no_ask"))
        last = _to_cents(m.get("last_price_dollars") or m.get("last_price"))
        volume = _to_float_size(m.get("volume_fp") or m.get("volume") or 0)
        oi = _to_float_size(m.get("open_interest_fp") or m.get("open_interest") or 0)
        yes_bid_sz = _to_float_size(m.get("yes_bid_size_fp") or m.get("yes_bid_size") or 0)
        yes_ask_sz = _to_float_size(m.get("yes_ask_size_fp") or m.get("yes_ask_size") or 0)

        # Fallback if only one side present
        if yes_ask == 0 and no_bid > 0:
            yes_ask = 100 - no_bid
        if no_ask == 0 and yes_bid > 0:
            no_ask = 100 - yes_bid
        if yes_bid == 0 and no_ask > 0:
            yes_bid = max(0, 100 - no_ask)
        if no_bid == 0 and yes_ask > 0:
            no_bid = max(0, 100 - yes_ask)

        return {
            "ticker": m.get("ticker", ""),
            "event_ticker": m.get("event_ticker", ""),
            "yes_bid": yes_bid,
            "yes_ask": yes_ask if yes_ask else 99,
            "no_bid": no_bid,
            "no_ask": no_ask if no_ask else 99,
            "last": last,
            "volume": volume,
            "open_interest": oi,
            "yes_bid_size": yes_bid_sz,
            "yes_ask_size": yes_ask_sz,
            "close_time": m.get("close_time") or m.get("expected_expiration_time") or "",
            "open_time": m.get("open_time") or "",
            "floor_strike": m.get("floor_strike"),
            "yes_sub_title": m.get("yes_sub_title") or "",
            "status": m.get("status") or "open",
            "raw": m,
        }

    def get_markets(
        self,
        series_ticker: str = "KXBTC15M",
        status: str = "open",
        limit: int = 10,
    ) -> list[dict]:
        data = self.get(
            "/markets",
            {"series_ticker": series_ticker, "status": status, "limit": limit},
        )
        markets = data.get("markets") or []
        return [self.normalize_market(m) for m in markets]

    def get_market(self, ticker: str) -> dict:
        data = self.get(f"/markets/{ticker}")
        m = data.get("market") or data
        return self.normalize_market(m)

    def get_orderbook(self, ticker: str, depth: int = 10) -> dict:
        try:
            return self.get(f"/markets/{ticker}/orderbook", {"depth": depth})
        except Exception:
            return {}

    def get_trades(self, ticker: str, limit: int = 50) -> list[dict]:
        try:
            data = self.get("/markets/trades", {"ticker": ticker, "limit": limit})
            return data.get("trades") or []
        except Exception:
            return []

    def get_balance(self) -> dict:
        if self.paper:
            return {"balance": 10_000_00}  # cents
        return self.get("/portfolio/balance")

    def get_positions(self) -> list[dict]:
        if self.paper:
            return []
        data = self.get("/portfolio/positions")
        return data.get("market_positions") or data.get("positions") or []

    def create_order(
        self,
        ticker: str,
        side: str,          # "yes" | "no"
        action: str,        # "buy" | "sell"
        count: int,
        yes_price: Optional[int] = None,
        no_price: Optional[int] = None,
        time_in_force: str = "good_till_canceled",
    ) -> dict:
        """Place a limit order. Prices are in cents (1-99)."""
        body: dict[str, Any] = {
            "ticker": ticker,
            "client_order_id": str(uuid.uuid4()),
            "side": side,
            "action": action,
            "count": int(count),
            "type": "limit",
            "time_in_force": time_in_force,
        }
        if yes_price is not None:
            body["yes_price"] = int(yes_price)
        if no_price is not None:
            body["no_price"] = int(no_price)

        return self.post("/portfolio/orders", body)

    def cancel_order(self, order_id: str) -> dict:
        if self.paper:
            print(f"  [PAPER] CANCEL {order_id}")
            return {"status": "canceled"}
        # Prefer DELETE; fall back to POST cancel if needed
        try:
            return self.delete(f"/portfolio/orders/{order_id}")
        except Exception:
            return self.post(f"/portfolio/orders/{order_id}/cancel", {})
