# XVANTAGE BTC 15-Minute Predictor

Research-grade **BTC 15-minute direction** predictor with:

- Multi-source live data (Binance klines / depth / trades / funding / OI + Coinbase cross-check)
- Multi-model ensemble (momentum, order-flow, structure, volatility, baseline)
- Market regime detection
- Pre-prediction self-critique
- Walk-forward historical backtest vs baselines
- SQLite prediction log + outcome resolution
- Model health monitoring
- Clean real-time dashboard (probabilities, confidence, data age — no fake “locks”)

**Not financial advice. For education and research only.**

## Quick start

```bash
pip install -r requirements.txt

# CLI (prints live predictions)
python bot.py

# Dashboard
python bot.py --web --port 8080

# Backtest only
python bot.py --backtest-only
```

## Performance (v3.2)

Data feed uses **parallel HTTP** (ThreadPoolExecutor) + **per-series TTL cache**:

| Mode | Latency |
|------|---------|
| Cold snapshot (all series) | ~0.9–1.3 s |
| Steady-state cycle (2 s poll) | ~0.15–0.30 s |

Higher timeframes (15m / 1h / 4h) refresh on longer cadences so the 2 s poll only hits ticker + book + trades + 1m most of the time. Funding / OI failures (e.g. geo 451) are cached to avoid hammering.

## Design principles

1. **Never force high confidence** — NEUTRAL when evidence is weak or models disagree.
2. **Show data age** — stale data is labeled, not hidden.
3. **Measure performance** — walk-forward accuracy, Brier score, vs prev-candle baseline.
4. **Log everything** — predictions resolved after 15 minutes for live calibration.

## Layout

```
core/           data_feed, features, models, regime, ensemble, critique, predictor
backtest/       walk-forward engine
learning/       SQLite DB + health monitor
bot.py          CLI + web entry
webapp.py       FastAPI
templates/      dashboard
```

## Disclaimer

15-minute BTC direction is extremely noisy. Any edge is small and unstable.
Past backtest results do not guarantee future performance.
