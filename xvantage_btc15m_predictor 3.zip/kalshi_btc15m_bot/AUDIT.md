# Final Audit — XVANTAGE BTC 15m Predictor

## What changed (full rebuild)

| Area | Before | After |
|------|--------|-------|
| Data | Coinbase spot only | Binance vision klines (1m–4h), depth, trades, Coinbase cross-check; age/stale flags |
| Features | ad-hoc mom % | Multi-TF returns, slope, RSI, ATR%, vol z-score, SMA structure, book/trade imbalance |
| Models | Single blended score | 5 independent models → weighted ensemble |
| Confidence | Often “locked” UI language | UP/DOWN probs + Low/Med/High; NEUTRAL when weak; never forced lock |
| Regime | none | trend_up/down, range, high/low vol, breakout, reversal |
| Critique | none | support/conflict/data-issue pass before final conf |
| Learning | CSV trades only | SQLite prediction log + 15m outcome resolution |
| Backtest | none | Walk-forward on closed 15m bars vs prev-candle & random baselines |
| Monitor | none | Accuracy / Brier flags on recent resolved preds |
| UI | Neon “CALL LOCKED” style | Clean probabilities, data age, model agreement, backtest stats |

## Measured out-of-sample performance

Walk-forward on ~360 recent 15m BTCUSDT bars (Binance public history). Features use only closed candles (no look-ahead). Book/trade flow unavailable historically → those models down-weighted.

| Conf threshold | N directional | Accuracy | F1 | Brier | Neutral rate | Prev-candle baseline |
|----------------|---------------|----------|-----|-------|--------------|----------------------|
| 0.08 | 204 | **45.1%** | 0.45 | 0.28 | 44% | 44.5% |
| 0.12 | 151 | **45.0%** | 0.44 | 0.29 | 58% | 44.5% |
| 0.18 | 85 | **47.1%** | 0.44 | 0.29 | 77% | 44.5% |
| 0.25 | 46 | **41.3%** | 0.36 | 0.31 | 87% | 44.5% |

**Interpretation:** On pure technical + structure features, the ensemble does **not** beat a coin flip or the previous-candle baseline on this window. Higher confidence thresholds do not reliably improve accuracy (calibration is weak). This is an honest negative result for short-horizon BTC direction with this feature set.

## What remains imperfect

1. **No demonstrated edge** on 15m direction with current models — system correctly defaults to NEUTRAL often.
2. Futures funding/OI blocked in some regions (451); treated as optional.
3. Historical backtest cannot include live order-book / trade aggression.
4. No trained ML model (logistic/gradient boost) on a large labeled set — would be the next step if seeking edge, with strict purge of leakage.
5. Live accuracy needs dozens of resolved predictions before monitoring is meaningful.
6. Kalshi market overlay (YES/NO prices) is separate from the BTC predictor core; original trading client still present but prediction is now the primary product.

## Reliability guarantees that *are* in place

- Data age displayed; stale snapshots marked unusable
- Venue divergence check (Binance vs Coinbase)
- Model disagreement lowers confidence
- Predictions logged with resolve_after = now+15m
- UI never shows “guaranteed” or 100% confidence
- Backtest metrics and baseline comparison always available (`python bot.py --backtest-only`)

## Recommendation

Treat this as a **monitoring + research harness**, not a production trading signal, until live logged accuracy and Brier score materially beat 50% / baseline over ≥200 resolved directional calls.
