"""
Position sizing, daily loss limits, cooldowns, and open-position tracking.
Includes simple mark-to-market helpers for paper mode.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class OpenPosition:
    ticker: str
    side: str
    entry_price_cents: int
    count: int
    entry_ts: float
    kind: str = "directional"  # directional | scalp | arb
    order_id: str = ""
    status: str = "open"


@dataclass
class RiskManager:
    max_daily_loss_usd: float = 30.0
    max_positions: int = 3
    stake_usd: float = 5.0
    cooldown_sec: float = 30.0

    daily_pnl: float = 0.0
    open_positions: List[OpenPosition] = field(default_factory=list)
    last_trade_ts: float = 0.0
    trades_today: int = 0
    wins_today: int = 0
    losses_today: int = 0

    def can_open(self, now: float | None = None) -> tuple[bool, str]:
        now = now or time.time()
        if self.daily_pnl <= -abs(self.max_daily_loss_usd):
            return False, "daily loss limit reached"
        if len(self.open_positions) >= self.max_positions:
            return False, f"max positions ({self.max_positions}) reached"
        if now - self.last_trade_ts < self.cooldown_sec:
            remaining = self.cooldown_sec - (now - self.last_trade_ts)
            return False, f"cooldown {remaining:.0f}s remaining"
        return True, "ok"

    def size_contracts(self, price_cents: int) -> int:
        if price_cents <= 0:
            return 0
        cost = price_cents / 100.0
        return max(1, int(self.stake_usd / cost))

    def register_open(
        self,
        ticker: str,
        side: str,
        price_cents: int,
        count: int,
        kind: str = "directional",
        order_id: str = "",
    ) -> OpenPosition:
        pos = OpenPosition(
            ticker=ticker,
            side=side,
            entry_price_cents=price_cents,
            count=count,
            entry_ts=time.time(),
            kind=kind,
            order_id=order_id,
        )
        self.open_positions.append(pos)
        self.last_trade_ts = time.time()
        self.trades_today += 1
        return pos

    def register_close(
        self,
        ticker: str,
        pnl_usd: float,
        side: Optional[str] = None,
    ) -> None:
        self.daily_pnl += pnl_usd
        if pnl_usd >= 0:
            self.wins_today += 1
        else:
            self.losses_today += 1
        kept = []
        for p in self.open_positions:
            if p.ticker == ticker and (side is None or p.side == side):
                continue
            kept.append(p)
        self.open_positions = kept

    def mark_pnl(
        self,
        ticker: str,
        side: str,
        current_mid_cents: float,
    ) -> Optional[float]:
        """Unrealized PnL in USD for matching open position(s)."""
        total = 0.0
        found = False
        for p in self.open_positions:
            if p.ticker != ticker or p.side != side:
                continue
            found = True
            # Long YES: value moves with yes mid; long NO: with no mid
            entry = p.entry_price_cents / 100.0
            if side == "yes":
                mark = current_mid_cents / 100.0
            else:
                mark = (100 - current_mid_cents) / 100.0
            total += (mark - entry) * p.count
        return total if found else None

    def summary(self) -> str:
        return (
            f"open={len(self.open_positions)}  "
            f"daily_pnl=${self.daily_pnl:+.2f}  "
            f"trades={self.trades_today}  "
            f"W/L={self.wins_today}/{self.losses_today}"
        )

    def to_dict(self) -> dict:
        return {
            "open": len(self.open_positions),
            "daily_pnl": round(self.daily_pnl, 2),
            "trades_today": self.trades_today,
            "wins": self.wins_today,
            "losses": self.losses_today,
            "positions": [
                {
                    "ticker": p.ticker,
                    "side": p.side,
                    "entry": p.entry_price_cents,
                    "count": p.count,
                    "kind": p.kind,
                    "age_s": int(time.time() - p.entry_ts),
                }
                for p in self.open_positions
            ],
        }
